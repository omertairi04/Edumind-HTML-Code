
const title = document.getElementById("titleInput");
const description = document.getElementById("descInput");

const createPost = () => {
    
    const newPost = {
        title: title.value.trim(),
        body: description.value.trim()
    }

    if (!newPost.title.length === 0) {
        alert("Title shouldn't be empty");
        return;
    }

    fetch('http://localhost:3000/posts', {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(newPost)
    })
    .then(response => response.json())
    .then(() => {
        window.location.replace('http://127.0.0.1:5500/socialMedia/htmlFiles/viewPosts.html')
    })
    .catch(err => console.log('Error: ', err));

    

}

