const postList = document.getElementById("posts");

// const fetchPosts = () => {
//     fetch('http://localhost:3000/posts')
//         .then(response => response.json())
//         .then(data => {
//             postList.innerHTML = "";

//             if (data.length === 0) {
//                 postList.innerHTML = "<li>No posts available</li>";
//                 return;
//             }

//             data.forEach(post => {
//                 const li = document.createElement("li");
//                 li.textContent = `${post.title}: ${post.body}`;
//                 postList.appendChild(li);
//             });
//         })
//         .catch(error => console.log("Error: " + error)); 
// };


const fetchPosts = async () => {
    const response = await fetch('http://localhost:3000/posts');

    /*
        {
            "response": {
                "ok" : true
            }

        }
    */


    if (response.ok === true) {
        const jsonResponse = await response.json();
        postList.innerHTML = "";

        if (jsonResponse.length === 0) {
            postList.innerHTML = "<li>No posts available</li>";
            return;
        }

        jsonResponse.forEach(post => {
            const li = document.createElement("li");
            li.textContent = `${post.title}: ${post.body}`;
            postList.appendChild(li);
        });
    } else {
        console.error("Failed to fetch posts");
    }
};

fetchPosts();



window.onload = fetchPosts;
